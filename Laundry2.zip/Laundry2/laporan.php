<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

require_once "config/database.php";

$database = new Database();
$db = $database->getConnection();

// ambil data laporan
$query = "SELECT t.id, t.invoice, m.name AS member, o.name AS outlet, u.name AS kasir, 
                 t.date, t.deadline, t.total, t.status, t.payment_status
          FROM transactions t
          LEFT JOIN members m ON t.member_id = m.id
          LEFT JOIN outlets o ON t.outlet_id = o.id
          LEFT JOIN users u ON t.user_id = u.id
          ORDER BY t.date DESC";
$stmt = $db->prepare($query);
$stmt->execute();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Transaksi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">
    <h2>Laporan Transaksi</h2>
    <a href="dashboard.php" class="btn btn-secondary mb-3">⬅ Kembali ke Dashboard</a>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Invoice</th>
                <th>Member</th>
                <th>Outlet</th>
                <th>Kasir</th>
                <th>Tanggal</th>
                <th>Deadline</th>
                <th>Total</th>
                <th>Status</th>
                <th>Pembayaran</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
            <tr>
                <td><?= $row['invoice'] ?></td>
                <td><?= $row['member'] ?></td>
                <td><?= $row['outlet'] ?></td>
                <td><?= $row['kasir'] ?></td>
                <td><?= $row['date'] ?></td>
                <td><?= $row['deadline'] ?></td>
                <td><?= number_format($row['total'],0,',','.') ?></td>
                <td><?= $row['status'] ?></td>
                <td><?= $row['payment_status'] ?></td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</body>
</html>
