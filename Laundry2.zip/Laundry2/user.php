<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Koneksi & Model
require_once "config/database.php";
require_once "models/User.php";

$database = new Database();
$db = $database->getConnection();

$user = new User($db);

// --- CREATE user ---
if (isset($_POST['create'])) {
    $user->outlet_id = $_POST['outlet_id'];
    $user->name = $_POST['name'];
    $user->username = $_POST['username'];
    $user->password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $user->role = $_POST['role'];

    if ($user->create()) {
        echo "<script>alert('User berhasil ditambahkan');window.location='user.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah user');</script>";
    }
}

// --- UPDATE user ---
if (isset($_POST['update'])) {
    $user->id = $_POST['id'];
    $user->outlet_id = $_POST['outlet_id'];
    $user->name = $_POST['name'];
    $user->username = $_POST['username'];
    $user->role = $_POST['role'];
    $user->password = !empty($_POST['password']) ? password_hash($_POST['password'], PASSWORD_DEFAULT) : null;

    if ($user->update()) {
        echo "<script>alert('User berhasil diupdate');window.location='user.php';</script>";
    } else {
        echo "<script>alert('Gagal update user');</script>";
    }
}

// --- DELETE user ---
if (isset($_GET['delete'])) {
    $user->id = $_GET['delete'];
    if ($user->delete()) {
        echo "<script>alert('User berhasil dihapus');window.location='user.php';</script>";
    } else {
        echo "<script>alert('Gagal hapus user');</script>";
    }
}

// --- READ semua user ---
$stmt = $user->read();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Manajemen User</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container py-4">
    <h2>Manajemen User</h2>
    <a href="dashboard.php" class="btn btn-secondary mb-3">⬅ Kembali ke Dashboard</a>

    <!-- Form Tambah User -->
    <div class="card mb-4">
        <div class="card-header">Tambah User</div>
        <div class="card-body">
            <form method="POST">
                <div class="row g-2">
                    <div class="col">
                        <input type="text" name="outlet_id" class="form-control" placeholder="ID Outlet" required>
                    </div>
                    <div class="col">
                        <input type="text" name="name" class="form-control" placeholder="Nama Lengkap" required>
                    </div>
                    <div class="col">
                        <input type="text" name="username" class="form-control" placeholder="Username" required>
                    </div>
                    <div class="col">
                        <input type="password" name="password" class="form-control" placeholder="Password" required>
                    </div>
                    <div class="col">
                        <select name="role" class="form-control">
                            <option value="admin">Admin</option>
                            <option value="kasir">Kasir</option>
                            <option value="owner">Owner</option>
                        </select>
                    </div>
                    <div class="col">
                        <button type="submit" name="create" class="btn btn-primary">Tambah</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel Data User -->
    <table class="table table-bordered table-striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>ID Outlet</th>
                <th>Nama</th>
                <th>Username</th>
                <th>Role</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) { ?>
            <tr>
                <td><?= $row['id'] ?></td>
                <td><?= $row['outlet_id'] ?></td>
                <td><?= $row['name'] ?></td>
                <td><?= $row['username'] ?></td>
                <td><?= $row['role'] ?></td>
                <td>
                    <!-- Form Update -->
                    <form method="POST" style="display:inline-block;">
                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                        <input type="text" name="outlet_id" value="<?= $row['outlet_id'] ?>" required>
                        <input type="text" name="name" value="<?= $row['name'] ?>" required>
                        <input type="text" name="username" value="<?= $row['username'] ?>" required>
                        <input type="password" name="password" placeholder="(Kosongkan jika tidak ubah)">
                        <select name="role">
                            <option value="admin" <?= $row['role']=="admin"?"selected":"" ?>>Admin</option>
                            <option value="kasir" <?= $row['role']=="kasir"?"selected":"" ?>>Kasir</option>
                            <option value="owner" <?= $row['role']=="owner"?"selected":"" ?>>Owner</option>
                        </select>
                        <button type="submit" name="update" class="btn btn-warning btn-sm">Update</button>
                    </form>

                    <!-- Tombol Delete -->
                    <a href="user.php?delete=<?= $row['id'] ?>" 
                       class="btn btn-danger btn-sm"
                       onclick="return confirm('Yakin hapus user ini?')">Hapus</a>
                </td>
            </tr>
        <?php } ?>
        </tbody>
    </table>
</body>
</html>
