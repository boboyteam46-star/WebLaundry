<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Tentukan bahwa halaman ini adalah halaman outlet
$current_page = 'outlet';

require_once "config/database.php";
require_once "models/Outlet.php";

// koneksi ke database
$database = new Database();
$db = $database->getConnection();

$outlet = new Outlet($db);

// --- CREATE ---
if (isset($_POST['create'])) {
    $outlet->name = $_POST['name'];
    $outlet->address = $_POST['address'];
    $outlet->phone = $_POST['phone'];
    if ($outlet->create()) {
        header("Location: outlet.php?message=Outlet+berhasil+ditambahkan&status=success");
        exit;
    } else {
        $error = "Gagal menambahkan outlet";
    }
}

// --- UPDATE ---
if (isset($_POST['update'])) {
    $outlet->id = $_POST['id'];
    $outlet->name = $_POST['name'];
    $outlet->address = $_POST['address'];
    $outlet->phone = $_POST['phone'];
    if ($outlet->update()) {
        header("Location: outlet.php?message=Outlet+berhasil+diupdate&status=success");
        exit;
    } else {
        $error = "Gagal update outlet";
    }
}

// --- DELETE ---
if (isset($_GET['delete'])) {
    $outlet->id = $_GET['delete'];
    if ($outlet->delete()) {
        header("Location: outlet.php?message=Outlet+berhasil+dihapus&status=success");
        exit;
    } else {
        $error = "Gagal hapus outlet";
    }
}

// --- READ ---
$stmt = $outlet->read();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Outlet - Aplikasi Laundry</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0 !important;
            background-color: #0d6efd;
            color: white;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .action-buttons {
            white-space: nowrap;
        }
        .modal-header {
            background-color: #0d6efd;
            color: white;
        }
        .nav-link.active {
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-house-fill"></i> Aplikasi Laundry
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'outlet' ? 'active' : ''; ?>" href="outlet.php">
                            <i class="bi bi-shop"></i> Outlet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'product' ? 'active' : ''; ?>" href="product.php">
                            <i class="bi bi-box-seam"></i> Produk
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'transaksi' ? 'active' : ''; ?>" href="transaksi.php">
                            <i class="bi bi-cash-coin"></i> Transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'laporan' ? 'active' : ''; ?>" href="laporan.php">
                            <i class="bi bi-bar-chart"></i> Laporan
                        </a>
                    </li>
                </ul>
                <span class="navbar-text me-3">
                    <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['name'] ?? 'Pengguna'); ?>
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h2><i class="bi bi-shop"></i> Kelola Outlet</h2>
            </div>
            <div class="col-md-6 text-end">
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahOutletModal">
                    <i class="bi bi-plus-circle"></i> Tambah Outlet
                </button>
            </div>
        </div>

        <!-- Alert Notifikasi -->
        <?php if(isset($_GET['message'])): ?>
        <div class="alert alert-<?php echo $_GET['status'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
            <?php echo htmlspecialchars(urldecode($_GET['message'])); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Card Daftar Outlet -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="bi bi-list"></i> Daftar Outlet</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Outlet</th>
                                <th>Alamat</th>
                                <th>Telepon</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): 
                            ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td><?php echo htmlspecialchars($row['address']); ?></td>
                                <td><?php echo htmlspecialchars($row['phone']); ?></td>
                                <td class="action-buttons">
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editOutletModal" 
                                        data-id="<?php echo $row['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>"
                                        data-address="<?php echo htmlspecialchars($row['address']); ?>"
                                        data-phone="<?php echo htmlspecialchars($row['phone']); ?>">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#hapusOutletModal" 
                                        data-id="<?php echo $row['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Outlet -->
    <div class="modal fade" id="tambahOutletModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Tambah Outlet Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="tambah_nama" class="form-label">Nama Outlet</label>
                            <input type="text" class="form-control" id="tambah_nama" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="tambah_alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="tambah_alamat" name="address" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="tambah_telepon" class="form-label">Telepon</label>
                            <input type="text" class="form-control" id="tambah_telepon" name="phone" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="create" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Outlet -->
    <div class="modal fade" id="editOutletModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Outlet</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_nama" class="form-label">Nama Outlet</label>
                            <input type="text" class="form-control" id="edit_nama" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_alamat" class="form-label">Alamat</label>
                            <textarea class="form-control" id="edit_alamat" name="address" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_telepon" class="form-label">Telepon</label>
                            <input type="text" class="form-control" id="edit_telepon" name="phone" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Hapus Outlet -->
    <div class="modal fade" id="hapusOutletModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-trash"></i> Hapus Outlet</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="GET" action="">
                    <div class="modal-body">
                        <input type="hidden" id="hapus_id" name="delete">
                        <p>Apakah Anda yakin ingin menghapus outlet <strong id="hapus_nama"></strong>?</p>
                        <p class="text-danger">Perhatian: Tindakan ini tidak dapat dibatalkan!</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Script untuk mengisi data ke modal edit
        var editOutletModal = document.getElementById('editOutletModal');
        editOutletModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var id = button.getAttribute('data-id');
            var name = button.getAttribute('data-name');
            var address = button.getAttribute('data-address');
            var phone = button.getAttribute('data-phone');
            
            var modalTitle = editOutletModal.querySelector('.modal-title');
            var modalBodyInputId = editOutletModal.querySelector('#edit_id');
            var modalBodyInputName = editOutletModal.querySelector('#edit_nama');
            var modalBodyInputAddress = editOutletModal.querySelector('#edit_alamat');
            var modalBodyInputPhone = editOutletModal.querySelector('#edit_telepon');
            
            modalTitle.textContent = 'Edit Outlet: ' + name;
            modalBodyInputId.value = id;
            modalBodyInputName.value = name;
            modalBodyInputAddress.value = address;
            modalBodyInputPhone.value = phone;
        });
        
        // Script untuk mengisi data ke modal hapus
        var hapusOutletModal = document.getElementById('hapusOutletModal');
        hapusOutletModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var id = button.getAttribute('data-id');
            var name = button.getAttribute('data-name');
            
            var modalBodyInputId = hapusOutletModal.querySelector('#hapus_id');
            var modalBodySpanName = hapusOutletModal.querySelector('#hapus_nama');
            
            modalBodyInputId.value = id;
            modalBodySpanName.textContent = name;
        });
    </script>
</body>
</html>