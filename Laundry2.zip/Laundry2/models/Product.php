<?php
class Product {
    private $conn;
    private $table_name = "packages";

    public $id;
    public $outlet_id;
    public $name;
    public $type;
    public $price;
    public $duration_in_days;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Ambil semua produk + nama outlet
    public function read() {
        $query = "SELECT p.id, p.outlet_id, p.name, p.type, p.price, p.duration_in_days, o.name AS outlet_name 
                  FROM " . $this->table_name . " p
                  JOIN outlets o ON p.outlet_id = o.id
                  ORDER BY p.id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Tambah produk
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (outlet_id, name, type, price, duration_in_days) 
                  VALUES (:outlet_id, :name, :type, :price, :duration_in_days)";
        $stmt = $this->conn->prepare($query);

        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->type = htmlspecialchars(strip_tags($this->type));

        $stmt->bindParam(":outlet_id", $this->outlet_id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":duration_in_days", $this->duration_in_days);

        return $stmt->execute();
    }

    // Update produk
    public function update() {
        $query = "UPDATE " . $this->table_name . " 
                  SET outlet_id = :outlet_id, name = :name, type = :type, 
                      price = :price, duration_in_days = :duration_in_days 
                  WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->name = htmlspecialchars(strip_tags($this->name));
        $this->type = htmlspecialchars(strip_tags($this->type));

        $stmt->bindParam(":outlet_id", $this->outlet_id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":price", $this->price);
        $stmt->bindParam(":duration_in_days", $this->duration_in_days);
        $stmt->bindParam(":id", $this->id);

        return $stmt->execute();
    }

    // Hapus produk
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        return $stmt->execute();
    }
}