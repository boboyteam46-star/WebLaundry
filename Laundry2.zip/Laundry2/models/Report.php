<?php
class Report {
    private $conn;
    private $table_name = "transactions";

    public function __construct($db) {
        $this->conn = $db;
    }

    // Laporan semua transaksi
    public function getAll() {
        $query = "SELECT t.*, m.name AS member_name, u.name AS user_name, o.name AS outlet_name 
                  FROM {$this->table_name} t
                  LEFT JOIN members m ON t.member_id = m.id 
                  LEFT JOIN users u ON t.user_id = u.id 
                  LEFT JOIN outlets o ON t.outlet_id = o.id 
                  ORDER BY t.date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Laporan berdasarkan tanggal
    public function getByDateRange($start_date, $end_date) {
        $query = "SELECT t.*, m.name AS member_name, u.name AS user_name, o.name AS outlet_name 
                  FROM {$this->table_name} t
                  LEFT JOIN members m ON t.member_id = m.id 
                  LEFT JOIN users u ON t.user_id = u.id 
                  LEFT JOIN outlets o ON t.outlet_id = o.id 
                  WHERE t.date BETWEEN :start_date AND :end_date
                  ORDER BY t.date DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":start_date", $start_date);
        $stmt->bindParam(":end_date", $end_date);
        $stmt->execute();
        return $stmt;
    }

    // Total pemasukan
    public function getTotalIncome() {
        $query = "SELECT COALESCE(SUM(total),0) as income 
                  FROM {$this->table_name} 
                  WHERE payment_status='lunas'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['income'] ?? 0;
    }
}
?>
