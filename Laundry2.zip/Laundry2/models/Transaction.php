<?php
class Transaction {
    private $conn;
    private $table_name = "transactions"; // pastikan nama tabel sesuai DB

    public $id;
    public $invoice;
    public $member_id;
    public $user_id;
    public $outlet_id;
    public $date;
    public $deadline;
    public $payment_status;
    public $paid_at;
    public $total;
    public $status;

    public function __construct($db) {
        $this->conn = $db;
    }

    // ✅ Ambil semua transaksi
    public function read() {
        $query = "SELECT t.*, 
                         m.name AS member_name, 
                         u.name AS user_name, 
                         o.name AS outlet_name 
                  FROM {$this->table_name} t
                  LEFT JOIN members m ON t.member_id = m.id 
                  LEFT JOIN users u ON t.user_id = u.id 
                  LEFT JOIN outlets o ON t.outlet_id = o.id 
                  ORDER BY t.created_at DESC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // ✅ Tambah transaksi baru
    public function create() {
        try {
            $this->invoice = "INV" . date('YmdHis');

            $query = "INSERT INTO {$this->table_name} 
                      (invoice, member_id, user_id, outlet_id, date, deadline, payment_status, paid_at, total, status, created_at)
                      VALUES (:invoice, :member_id, :user_id, :outlet_id, :date, :deadline, :payment_status, :paid_at, :total, :status, NOW())";

            $stmt = $this->conn->prepare($query);

            // Sanitasi input
            $this->member_id = htmlspecialchars(strip_tags($this->member_id));
            $this->user_id = htmlspecialchars(strip_tags($this->user_id));
            $this->outlet_id = htmlspecialchars(strip_tags($this->outlet_id));
            $this->date = htmlspecialchars(strip_tags($this->date));
            $this->deadline = htmlspecialchars(strip_tags($this->deadline));
            $this->payment_status = htmlspecialchars(strip_tags($this->payment_status));
            $this->total = htmlspecialchars(strip_tags($this->total));
            $this->status = htmlspecialchars(strip_tags($this->status));

            $paidAt = ($this->payment_status === "lunas") ? date("Y-m-d H:i:s") : null;

            $stmt->bindParam(":invoice", $this->invoice);
            $stmt->bindParam(":member_id", $this->member_id);
            $stmt->bindParam(":user_id", $this->user_id);
            $stmt->bindParam(":outlet_id", $this->outlet_id);
            $stmt->bindParam(":date", $this->date);
            $stmt->bindParam(":deadline", $this->deadline);
            $stmt->bindParam(":payment_status", $this->payment_status);
            $stmt->bindValue(":paid_at", $paidAt);
            $stmt->bindParam(":total", $this->total);
            $stmt->bindParam(":status", $this->status);

            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Create Transaction Error: " . $e->getMessage());
            return false;
        }
    }

    // ✅ Update transaksi
    public function update() {
        try {
            $query = "UPDATE {$this->table_name} 
                      SET member_id=:member_id, 
                          user_id=:user_id,
                          outlet_id=:outlet_id, 
                          date=:date, deadline=:deadline, 
                          payment_status=:payment_status, 
                          paid_at=:paid_at,
                          total=:total, 
                          status=:status 
                      WHERE id=:id";

            $stmt = $this->conn->prepare($query);

            $this->member_id = htmlspecialchars(strip_tags($this->member_id));
            $this->user_id = htmlspecialchars(strip_tags($this->user_id));
            $this->outlet_id = htmlspecialchars(strip_tags($this->outlet_id));
            $this->date = htmlspecialchars(strip_tags($this->date));
            $this->deadline = htmlspecialchars(strip_tags($this->deadline));
            $this->payment_status = htmlspecialchars(strip_tags($this->payment_status));
            $this->total = htmlspecialchars(strip_tags($this->total));
            $this->status = htmlspecialchars(strip_tags($this->status));
            $this->id = htmlspecialchars(strip_tags($this->id));

            $paidAt = ($this->payment_status === "lunas") ? date("Y-m-d H:i:s") : null;

            $stmt->bindParam(":member_id", $this->member_id);
            $stmt->bindParam(":user_id", $this->user_id);
            $stmt->bindParam(":outlet_id", $this->outlet_id);
            $stmt->bindParam(":date", $this->date);
            $stmt->bindParam(":deadline", $this->deadline);
            $stmt->bindParam(":payment_status", $this->payment_status);
            $stmt->bindValue(":paid_at", $paidAt);
            $stmt->bindParam(":total", $this->total);
            $stmt->bindParam(":status", $this->status);
            $stmt->bindParam(":id", $this->id);

            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Update Transaction Error: " . $e->getMessage());
            return false;
        }
    }

    // ✅ Hapus transaksi
    public function delete() {
        try {
            $query = "DELETE FROM {$this->table_name} WHERE id = :id";
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(":id", $this->id);
            return $stmt->execute();
        } catch (PDOException $e) {
            error_log("Delete Transaction Error: " . $e->getMessage());
            return false;
        }
    }

    // ✅ Hitung transaksi hari ini
    public function getTodayTransactions() {
        $query = "SELECT COUNT(*) as total 
                  FROM {$this->table_name} 
                  WHERE DATE(date) = CURDATE()";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['total'] ?? 0;
    }

    // ✅ Hitung pemasukan bulan ini
    public function getMonthlyIncome() {
        $query = "SELECT COALESCE(SUM(total), 0) as income 
                  FROM {$this->table_name} 
                  WHERE MONTH(date) = MONTH(CURDATE()) 
                    AND YEAR(date) = YEAR(CURDATE())
                    AND payment_status = 'lunas'";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['income'] ?? 0;
    }
}
?>
