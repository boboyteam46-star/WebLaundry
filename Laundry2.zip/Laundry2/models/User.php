<?php
class User {
    private $conn;
    private $table_name = "users";

    public $id;
    public $outlet_id;
    public $name;
    public $username;
    public $password;
    public $role;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Ambil semua user
    public function read() {
        $query = "SELECT id, outlet_id, name, username, role 
                  FROM " . $this->table_name . " 
                  ORDER BY id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Tambah user
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " 
                  (outlet_id, name, username, password, role) 
                  VALUES (:outlet_id, :name, :username, :password, :role)";
        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":outlet_id", $this->outlet_id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":password", $this->password);
        $stmt->bindParam(":role", $this->role);

        return $stmt->execute();
    }

    // Update user
    public function update() {
        if ($this->password) {
            $query = "UPDATE " . $this->table_name . " 
                      SET outlet_id = :outlet_id, name = :name, username = :username, password = :password, role = :role 
                      WHERE id = :id";
        } else {
            $query = "UPDATE " . $this->table_name . " 
                      SET outlet_id = :outlet_id, name = :name, username = :username, role = :role 
                      WHERE id = :id";
        }

        $stmt = $this->conn->prepare($query);

        $stmt->bindParam(":outlet_id", $this->outlet_id);
        $stmt->bindParam(":name", $this->name);
        $stmt->bindParam(":username", $this->username);
        $stmt->bindParam(":role", $this->role);
        $stmt->bindParam(":id", $this->id);

        if ($this->password) {
            $stmt->bindParam(":password", $this->password);
        }

        return $stmt->execute();
    }

    // Hapus user
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(":id", $this->id);
        return $stmt->execute();
    }
}
