<?php
// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include file yang diperlukan
require_once "config/database.php";
require_once "models/Product.php";

// Inisialisasi koneksi database
$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

// CREATE - Tambah Paket Baru
if (isset($_POST['create'])) {
    $product->outlet_id = $_POST['outlet_id'];
    $product->name = $_POST['nama'];
    $product->type = $_POST['type'];
    $product->price = $_POST['price'];
    $product->duration_in_days = $_POST['duration_in_days'];
    
    if ($product->create()) {
        header("Location: product.php?message=Paket+berhasil+ditambahkan&status=success");
    } else {
        header("Location: product.php?message=Gagal+menambahkan+paket&status=error");
    }
    exit;
}

// UPDATE - Edit Paket
if (isset($_POST['update'])) {
    $product->id = $_POST['id'];
    $product->outlet_id = $_POST['outlet_id'];
    $product->name = $_POST['nama'];
    $product->type = $_POST['type'];
    $product->price = $_POST['price'];
    $product->duration_in_days = $_POST['duration_in_days'];
    
    if ($product->update()) {
        header("Location: product.php?message=Paket+berhasil+diupdate&status=success");
    } else {
        header("Location: product.php?message=Gagal+update+paket&status=error");
    }
    exit;
}

// DELETE - Hapus Paket
if (isset($_POST['delete'])) {
    $product->id = $_POST['id'];
    
    if ($product->delete()) {
        header("Location: product.php?message=Paket+berhasil+dihapus&status=success");
    } else {
        header("Location: product.php?message=Gagal+menghapus+paket&status=error");
    }
    exit;
}

// Jika tidak ada aksi yang valid, redirect ke halaman product.php
header("Location: product.php");
exit;
?>