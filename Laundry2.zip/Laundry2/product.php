<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Tentukan bahwa halaman ini adalah halaman product
$current_page = 'product';

require_once "config/database.php";
require_once "models/Product.php";

$database = new Database();
$db = $database->getConnection();
$product = new Product($db);

// CREATE
if (isset($_POST['create'])) {
    $product->outlet_id = $_POST['outlet_id'];
    $product->name = $_POST['name'];
    $product->type = $_POST['type'];
    $product->price = $_POST['price'];
    $product->duration_in_days = $_POST['duration_in_days'];
    
    if ($product->create()) {
        header("Location: product.php?message=Paket+berhasil+ditambahkan&status=success");
        exit;
    } else {
        $error = "Gagal menambahkan paket";
    }
}

// UPDATE
if (isset($_POST['update'])) {
    $product->id = $_POST['id'];
    $product->outlet_id = $_POST['outlet_id'];
    $product->name = $_POST['name'];
    $product->type = $_POST['type'];
    $product->price = $_POST['price'];
    $product->duration_in_days = $_POST['duration_in_days'];
    
    if ($product->update()) {
        header("Location: product.php?message=Paket+berhasil+diupdate&status=success");
        exit;
    } else {
        $error = "Gagal update paket";
    }
}

// DELETE
if (isset($_GET['delete'])) {
    $product->id = $_GET['delete'];
    
    if ($product->delete()) {
        header("Location: product.php?message=Paket+berhasil+dihapus&status=success");
        exit;
    } else {
        $error = "Gagal menghapus paket";
    }
}

// Ambil data produk dari database
$query = "SELECT p.id, p.name, p.type, p.price, p.duration_in_days, o.name AS outlet_name 
          FROM packages p 
          JOIN outlets o ON p.outlet_id = o.id 
          ORDER BY p.id DESC";
$stmt = $db->prepare($query);
$stmt->execute();

// Ambil data outlet untuk dropdown
$outlets = $db->query("SELECT id, name FROM outlets ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Produk - Aplikasi Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0 !important;
            background-color: #0d6efd;
            color: white;
        }
        .btn-primary {
            background-color: #0d6efd;
            border-color: #0d6efd;
        }
        .btn-primary:hover {
            background-color: #0b5ed7;
            border-color: #0a58ca;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .action-buttons {
            white-space: nowrap;
        }
        .modal-header {
            background-color: #0d6efd;
            color: white;
        }
        .price-cell {
            text-align: right;
        }
        .badge-kiloan { background-color: #6f42c1; }
        .badge-selimut { background-color: #fd7e14; }
        .badge-bed_cover { background-color: #20c997; }
        .badge-kaos { background-color: #0dcaf0; }
        .badge-lainnya { background-color: #6c757d; }
        .nav-link.active {
            font-weight: bold;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 5px;
        }
    </style>
</head>
<body class="bg-light">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-house-fill"></i> Aplikasi Laundry
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'dashboard' ? 'active' : ''; ?>" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'outlet' ? 'active' : ''; ?>" href="outlet.php">
                            <i class="bi bi-shop"></i> Outlet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'product' ? 'active' : ''; ?>" href="product.php">
                            <i class="bi bi-box-seam"></i> Produk
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'transaksi' ? 'active' : ''; ?>" href="transaksi.php">
                            <i class="bi bi-cash-coin"></i> Transaksi
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?php echo $current_page == 'laporan' ? 'active' : ''; ?>" href="laporan.php">
                            <i class="bi bi-bar-chart"></i> Laporan
                        </a>
                    </li>
                </ul>
                <span class="navbar-text me-3">
                    <i class="bi bi-person-circle"></i> <?php echo htmlspecialchars($_SESSION['name'] ?? 'Pengguna'); ?>
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h2><i class="bi bi-box-seam"></i> Kelola Paket Layanan</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="outlet.php" class="btn btn-info me-2">
                    <i class="bi bi-shop"></i> Kelola Outlet
                </a>
                <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#tambahProdukModal">
                    <i class="bi bi-plus-circle"></i> Tambah Paket
                </button>
            </div>
        </div>

        <!-- Alert Notifikasi -->
        <?php if(isset($_GET['message'])): ?>
        <div class="alert alert-<?php echo $_GET['status'] == 'success' ? 'success' : 'danger'; ?> alert-dismissible fade show">
            <?php echo htmlspecialchars(urldecode($_GET['message'])); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        
        <?php if(isset($error)): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <?php echo $error; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- Card Daftar Produk -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="bi bi-list"></i> Daftar Paket Layanan</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nama Paket</th>
                                <th>Jenis</th>
                                <th>Outlet</th>
                                <th class="price-cell">Harga</th>
                                <th>Durasi (Hari)</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $no = 1;
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): 
                                // Tentukan class badge berdasarkan jenis
                                $badge_class = 'badge-lainnya';
                                switch($row['type']) {
                                    case 'kiloan': $badge_class = 'badge-kiloan'; break;
                                    case 'selimut': $badge_class = 'badge-selimut'; break;
                                    case 'bed_cover': $badge_class = 'badge-bed_cover'; break;
                                    case 'kaos': $badge_class = 'badge-kaos'; break;
                                    default: $badge_class = 'badge-lainnya';
                                }
                            ?>
                            <tr>
                                <td><?php echo $no++; ?></td>
                                <td><?php echo htmlspecialchars($row['name']); ?></td>
                                <td>
                                    <span class="badge <?php echo $badge_class; ?>">
                                        <?php 
                                        $jenis_labels = [
                                            'kiloan' => 'Kiloan',
                                            'selimut' => 'Selimut',
                                            'bed_cover' => 'Bed Cover',
                                            'kaos' => 'Kaos',
                                            'lainnya' => 'Lainnya'
                                        ];
                                        echo $jenis_labels[$row['type']] ?? 'Lainnya'; 
                                        ?>
                                    </span>
                                </td>
                                <td><?php echo htmlspecialchars($row['outlet_name']); ?></td>
                                <td class="price-cell">Rp <?php echo number_format($row['price'], 0, ',', '.'); ?></td>
                                <td class="text-center"><?php echo $row['duration_in_days']; ?></td>
                                <td class="action-buttons">
                                    <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editProdukModal" 
                                        data-id="<?php echo $row['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>"
                                        data-type="<?php echo $row['type']; ?>"
                                        data-outlet_id="<?php 
                                            // Ambil outlet_id untuk produk ini
                                            $query_outlet = "SELECT outlet_id FROM packages WHERE id = ?";
                                            $stmt_outlet = $db->prepare($query_outlet);
                                            $stmt_outlet->execute([$row['id']]);
                                            $outlet_data = $stmt_outlet->fetch(PDO::FETCH_ASSOC);
                                            echo $outlet_data['outlet_id'];
                                        ?>"
                                        data-price="<?php echo $row['price']; ?>"
                                        data-duration="<?php echo $row['duration_in_days']; ?>">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </button>
                                    <button class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#hapusProdukModal" 
                                        data-id="<?php echo $row['id']; ?>"
                                        data-name="<?php echo htmlspecialchars($row['name']); ?>">
                                        <i class="bi bi-trash"></i> Hapus
                                    </button>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Tambah Produk -->
    <div class="modal fade" id="tambahProdukModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle"></i> Tambah Paket Baru</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Paket</label>
                            <input type="text" class="form-control" id="nama" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="jenis" class="form-label">Jenis Layanan</label>
                            <select class="form-select" id="jenis" name="type" required>
                                <option value="">Pilih Jenis Layanan</option>
                                <option value="kiloan">Kiloan</option>
                                <option value="selimut">Selimut</option>
                                <option value="bed_cover">Bed Cover</option>
                                <option value="kaos">Kaos</option>
                                <option value="lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="outlet" class="form-label">Outlet</label>
                            <select class="form-select" id="outlet" name="outlet_id" required>
                                <option value="">Pilih Outlet</option>
                                <?php foreach ($outlets as $outlet): ?>
                                <option value="<?php echo $outlet['id']; ?>"><?php echo htmlspecialchars($outlet['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="harga" class="form-label">Harga (Rp)</label>
                            <input type="number" class="form-control" id="harga" name="price" min="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="durasi" class="form-label">Durasi Pengerjaan (Hari)</label>
                            <input type="number" class="form-control" id="durasi" name="duration_in_days" min="1" value="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="create" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Edit Produk -->
    <div class="modal fade" id="editProdukModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil-square"></i> Edit Paket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" action="">
                    <div class="modal-body">
                        <input type="hidden" id="edit_id" name="id">
                        <div class="mb-3">
                            <label for="edit_nama" class="form-label">Nama Paket</label>
                            <input type="text" class="form-control" id="edit_nama" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_jenis" class="form-label">Jenis Layanan</label>
                            <select class="form-select" id="edit_jenis" name="type" required>
                                <option value="kiloan">Kiloan</option>
                                <option value="selimut">Selimut</option>
                                <option value="bed_cover">Bed Cover</option>
                                <option value="kaos">Kaos</option>
                                <option value="lainnya">Lainnya</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_outlet" class="form-label">Outlet</label>
                            <select class="form-select" id="edit_outlet" name="outlet_id" required>
                                <?php foreach ($outlets as $outlet): ?>
                                <option value="<?php echo $outlet['id']; ?>"><?php echo htmlspecialchars($outlet['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="edit_harga" class="form-label">Harga (Rp)</label>
                            <input type="number" class="form-control" id="edit_harga" name="price" min="0" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_durasi" class="form-label">Durasi Pengerjaan (Hari)</label>
                            <input type="number" class="form-control" id="edit_durasi" name="duration_in_days" min="1" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Modal Hapus Produk -->
    <div class="modal fade" id="hapusProdukModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-trash"></i> Hapus Paket</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="GET" action="">
                    <div class="modal-body">
                        <input type="hidden" id="hapus_id" name="delete">
                        <p>Apakah Anda yakin ingin menghapus paket <strong id="hapus_nama"></strong>?</p>
                        <p class="text-danger">Perhatian: Tindakan ini tidak dapat dibatalkan!</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Script untuk mengisi data ke modal edit
        var editProdukModal = document.getElementById('editProdukModal');
        editProdukModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var id = button.getAttribute('data-id');
            var name = button.getAttribute('data-name');
            var type = button.getAttribute('data-type');
            var outlet_id = button.getAttribute('data-outlet_id');
            var price = button.getAttribute('data-price');
            var duration = button.getAttribute('data-duration');
            
            var modalTitle = editProdukModal.querySelector('.modal-title');
            var modalBodyInputId = editProdukModal.querySelector('#edit_id');
            var modalBodyInputName = editProdukModal.querySelector('#edit_nama');
            var modalBodyInputType = editProdukModal.querySelector('#edit_jenis');
            var modalBodyInputOutlet = editProdukModal.querySelector('#edit_outlet');
            var modalBodyInputPrice = editProdukModal.querySelector('#edit_harga');
            var modalBodyInputDuration = editProdukModal.querySelector('#edit_durasi');
            
            modalTitle.textContent = 'Edit Paket: ' + name;
            modalBodyInputId.value = id;
            modalBodyInputName.value = name;
            modalBodyInputType.value = type;
            modalBodyInputPrice.value = price;
            modalBodyInputDuration.value = duration;
            
            // Set selected outlet
            modalBodyInputOutlet.value = outlet_id;
        });
        
        // Script untuk mengisi data ke modal hapus
        var hapusProdukModal = document.getElementById('hapusProdukModal');
        hapusProdukModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var id = button.getAttribute('data-id');
            var name = button.getAttribute('data-name');
            
            var modalBodyInputId = hapusProdukModal.querySelector('#hapus_id');
            var modalBodySpanName = hapusProdukModal.querySelector('#hapus_nama');
            
            modalBodyInputId.value = id;
            modalBodySpanName.textContent = name;
        });
    </script>
</body>
</html>