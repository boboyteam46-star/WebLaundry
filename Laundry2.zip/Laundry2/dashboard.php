<?php
session_start();

// Jika belum login, redirect ke halaman login
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Ambil data user dari session
$name = $_SESSION['name'] ?? 'Pengguna';
$role = $_SESSION['role'] ?? 'guest';
$username = $_SESSION['username'] ?? '';

// Koneksi database untuk statistik
require_once "config/database.php";
$database = new Database();
$db = $database->getConnection();

// Hitung jumlah member
$member_count = $db->query("SELECT COUNT(*) as total FROM members")->fetch(PDO::FETCH_ASSOC)['total'];

// Hitung jumlah transaksi hari ini
$transaction_count = $db->query("SELECT COUNT(*) as total FROM transactions WHERE DATE(date) = CURDATE()")->fetch(PDO::FETCH_ASSOC)['total'];

// Hitung pendapatan bulan ini
$revenue = $db->query("SELECT COALESCE(SUM(total), 0) as total FROM transactions WHERE payment_status = 'lunas' AND MONTH(date) = MONTH(CURDATE()) AND YEAR(date) = YEAR(CURDATE())")->fetch(PDO::FETCH_ASSOC)['total'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Aplikasi Laundry</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }
        .card:hover {
            transform: translateY(-5px);
        }
        .card-header {
            border-radius: 10px 10px 0 0 !important;
        }
        .stats-card {
            text-align: center;
        }
        .stats-number {
            font-size: 2rem;
            font-weight: bold;
        }
        .bg-primary { background-color: #0d6efd !important; }
        .bg-success { background-color: #198754 !important; }
        .bg-info { background-color: #0dcaf0 !important; }
        .bg-warning { background-color: #ffc107 !important; }
    </style>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="#">
                <i class="bi bi-house-fill"></i> Aplikasi Laundry
            </a>
            <div class="d-flex">
                <span class="navbar-text text-white me-3">
                    <i class="bi bi-person-circle"></i> Halo, <b><?php echo htmlspecialchars($name); ?></b> (<?php echo $role; ?>)
                </span>
                <a href="logout.php" class="btn btn-outline-light btn-sm">
                    <i class="bi bi-box-arrow-right"></i> Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="alert alert-success">
            <i class="bi bi-check-circle-fill"></i> Selamat datang <b><?php echo htmlspecialchars($name); ?></b>!  
            Anda login sebagai <b><?php echo ucfirst($role); ?></b>.
        </div>

        <!-- Statistik Dashboard -->
        <div class="row mb-4">
            <div class="col-md-4 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body stats-card">
                        <i class="bi bi-people-fill" style="font-size: 2rem;"></i>
                        <div class="stats-number"><?php echo $member_count; ?></div>
                        <div>Total Member</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-success text-white">
                    <div class="card-body stats-card">
                        <i class="bi bi-receipt" style="font-size: 2rem;"></i>
                        <div class="stats-number"><?php echo $transaction_count; ?></div>
                        <div>Transaksi Hari Ini</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card bg-info text-white">
                    <div class="card-body stats-card">
                        <i class="bi bi-currency-exchange" style="font-size: 2rem;"></i>
                        <div class="stats-number">Rp <?php echo number_format($revenue, 0, ',', '.'); ?></div>
                        <div>Pendapatan Bulan Ini</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu Berdasarkan Role -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="card-title mb-0">
                            <i class="bi bi-menu-button"></i> Menu Aplikasi
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if ($role == 'admin'): ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <h5>Menu Admin</h5>
                                    <div class="list-group">
                                        <a href="outlet.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-shop"></i> Kelola Outlet
                                        </a>
                                        <a href="product.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-box-seam"></i> Kelola Produk/Paket
                                        </a>
                                        <a href="user.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-people"></i> Kelola Pengguna
                                        </a>
                                        <a href="tambah_member.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-person-plus"></i> Kelola Member
                                        </a>
                                        <a href="transaksi.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-cash-coin"></i> Entri Transaksi
                                        </a>
                                        <a href="laporan.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-bar-chart"></i> Laporan
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h5>Quick Actions</h5>
                                    <div class="d-grid gap-2">
                                        <a href="tambah_member.php" class="btn btn-outline-primary">
                                            <i class="bi bi-person-plus"></i> Tambah Member Baru
                                        </a>
                                        <a href="transaksi.php" class="btn btn-outline-success">
                                            <i class="bi bi-plus-circle"></i> Buat Transaksi Baru
                                        </a>
                                        <a href="product.php" class="btn btn-outline-info">
                                            <i class="bi bi-box"></i> Kelola Paket Layanan
                                        </a>
                                    </div>
                                </div>
                            </div>

                        <?php elseif ($role == 'kasir'): ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <h5>Menu Kasir</h5>
                                    <div class="list-group">
                                        <a href="transaksi.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-cash-coin"></i> Entri Transaksi
                                        </a>
                                        <a href="tambah_member.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-person-plus"></i> Kelola Member
                                        </a>
                                        <a href="laporan.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-bar-chart"></i> Laporan Transaksi
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h5>Quick Actions</h5>
                                    <div class="d-grid gap-2">
                                        <a href="transaksi.php" class="btn btn-outline-success">
                                            <i class="bi bi-plus-circle"></i> Buat Transaksi Baru
                                        </a>
                                        <a href="tambah_member.php" class="btn btn-outline-primary">
                                            <i class="bi bi-person-plus"></i> Tambah Member Baru
                                        </a>
                                    </div>
                                </div>
                            </div>

                        <?php elseif ($role == 'owner'): ?>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <h5>Menu Owner</h5>
                                    <div class="list-group">
                                        <a href="laporan.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-bar-chart"></i> Lihat Laporan
                                        </a>
                                        <a href="tambah_member.php" class="list-group-item list-group-item-action">
                                            <i class="bi bi-people"></i> Data Member
                                        </a>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <h5>Statistik</h5>
                                    <div class="card bg-light">
                                        <div class="card-body">
                                            <p><i class="bi bi-people"></i> <strong>Total Member:</strong> <?php echo $member_count; ?></p>
                                            <p><i class="bi bi-receipt"></i> <strong>Transaksi Hari Ini:</strong> <?php echo $transaction_count; ?></p>
                                            <p><i class="bi bi-currency-exchange"></i> <strong>Pendapatan Bulan Ini:</strong> Rp <?php echo number_format($revenue, 0, ',', '.'); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        <?php else: ?>
                            <div class="alert alert-warning">
                                <i class="bi bi-exclamation-triangle"></i> Role tidak dikenal. Hubungi administrator.
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>