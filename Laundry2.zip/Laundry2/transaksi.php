<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Koneksi & Model
require_once "config/database.php";
require_once "models/transaction.php";

$database = new Database();
$db = $database->getConnection();

$transaction = new Transaction($db);

// Ambil data outlet untuk dropdown
$outlets = $db->query("SELECT id, name FROM outlets ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Ambil data member untuk dropdown
$members = $db->query("SELECT id, name FROM members ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// Ambil data paket untuk dropdown
$packages = $db->query("SELECT id, name, price FROM packages ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);

// --- CREATE transaksi ---
if (isset($_POST['create'])) {
    $transaction->member_id = $_POST['member_id'];
    $transaction->user_id = $_SESSION['user_id'];
    $transaction->outlet_id = $_POST['outlet_id'];
    $transaction->date = date("Y-m-d H:i:s");
    $transaction->deadline = $_POST['deadline'];
    $transaction->payment_status = $_POST['payment_status'];
    $transaction->total = $_POST['total'];
    $transaction->status = $_POST['status'];

    if ($transaction->create()) {
        echo "<script>alert('Transaksi berhasil ditambahkan');window.location='transaksi.php';</script>";
    } else {
        echo "<script>alert('Gagal menambah transaksi');</script>";
    }
}

// --- UPDATE transaksi ---
if (isset($_POST['update'])) {
    $transaction->id = $_POST['id'];
    $transaction->member_id = $_POST['member_id'];
    $transaction->outlet_id = $_POST['outlet_id'];
    $transaction->date = $_POST['date'];
    $transaction->deadline = $_POST['deadline'];
    $transaction->payment_status = $_POST['payment_status'];
    $transaction->total = $_POST['total'];
    $transaction->status = $_POST['status'];

    if ($transaction->update()) {
        echo "<script>alert('Transaksi berhasil diupdate');window.location='transaksi.php';</script>";
    } else {
        echo "<script>alert('Gagal update transaksi');</script>";
    }
}

// --- DELETE transaksi ---
if (isset($_GET['delete'])) {
    $transaction->id = $_GET['delete'];
    if ($transaction->delete()) {
        echo "<script>alert('Transaksi berhasil dihapus');window.location='transaksi.php';</script>";
    } else {
        echo "<script>alert('Gagal hapus transaksi');</script>";
    }
}

// --- READ semua transaksi ---
$stmt = $transaction->read();
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Transaksi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <style>
        .card {
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        .card-header {
            border-radius: 10px 10px 0 0 !important;
            background-color: #0d6efd;
            color: white;
        }
        .table th {
            background-color: #f8f9fa;
        }
        .status-baru { background-color: #fff3cd; }
        .status-proses { background-color: #cce7ff; }
        .status-selesai { background-color: #d4edda; }
        .status-diambil { background-color: #d1ecf1; }
        .payment-lunas { background-color: #d4edda; }
        .payment-belum { background-color: #f8d7da; }
        .package-item { border-bottom: 1px solid #eee; padding: 10px 0; }
        .package-item:last-child { border-bottom: none; }
    </style>
</head>
<body class="bg-light">
    <div class="container py-4">
        <div class="row mb-4">
            <div class="col-md-6">
                <h2><i class="bi bi-cash-coin"></i> Manajemen Transaksi</h2>
            </div>
            <div class="col-md-6 text-end">
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
                </a>
            </div>
        </div>

        <!-- Form Tambah Transaksi -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="bi bi-plus-circle"></i> Tambah Transaksi Baru</h5>
            </div>
            <div class="card-body">
                <form method="POST" id="transactionForm">
                    <div class="row g-3">
                        <div class="col-md-4">
                            <label for="member_id" class="form-label">Member</label>
                            <select class="form-select" id="member_id" name="member_id" required>
                                <option value="">Pilih Member</option>
                                <?php foreach ($members as $member): ?>
                                    <option value="<?= $member['id'] ?>"><?= htmlspecialchars($member['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="outlet_id" class="form-label">Outlet</label>
                            <select class="form-select" id="outlet_id" name="outlet_id" required>
                                <option value="">Pilih Outlet</option>
                                <?php foreach ($outlets as $outlet): ?>
                                    <option value="<?= $outlet['id'] ?>"><?= htmlspecialchars($outlet['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="deadline" class="form-label">Deadline</label>
                            <input type="date" class="form-control" id="deadline" name="deadline" required>
                        </div>
                        
                        <!-- Paket Layanan -->
                        <div class="col-12">
                            <h6 class="border-bottom pb-2">Paket Layanan</h6>
                            <div id="packageContainer">
                                <div class="package-item row g-2">
                                    <div class="col-md-5">
                                        <select class="form-select package-select" name="package_id[]" onchange="updateTotal()">
                                            <option value="">Pilih Paket</option>
                                            <?php foreach ($packages as $package): ?>
                                                <option value="<?= $package['id'] ?>" data-price="<?= $package['price'] ?>">
                                                    <?= htmlspecialchars($package['name']) ?> - Rp <?= number_format($package['price'], 0, ',', '.') ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-3">
                                        <input type="number" class="form-control package-qty" name="package_qty[]" value="1" min="1" onchange="updateTotal()" placeholder="Jumlah">
                                    </div>
                                    <div class="col-md-3">
                                        <input type="text" class="form-control package-subtotal" readonly placeholder="Subtotal">
                                    </div>
                                    <div class="col-md-1">
                                        <button type="button" class="btn btn-danger btn-sm remove-package" onclick="removePackage(this)">
                                            <i class="bi bi-trash"></i>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <button type="button" class="btn btn-outline-primary btn-sm mt-2" onclick="addPackage()">
                                <i class="bi bi-plus"></i> Tambah Paket
                            </button>
                        </div>
                        
                        <div class="col-md-4">
                            <label for="total" class="form-label">Total (Rp)</label>
                            <input type="text" class="form-control" id="total" name="total" readonly>
                        </div>
                        <div class="col-md-4">
                            <label for="payment_status" class="form-label">Status Pembayaran</label>
                            <select class="form-select" id="payment_status" name="payment_status" required>
                                <option value="belum_dibayar">Belum Dibayar</option>
                                <option value="lunas">Lunas</option>
                            </select>
                        </div>
                        <div class="col-md-4">
                            <label for="status" class="form-label">Status Laundry</label>
                            <select class="form-select" id="status" name="status" required>
                                <option value="baru">Baru</option>
                                <option value="proses">Proses</option>
                                <option value="selesai">Selesai</option>
                                <option value="diambil">Diambil</option>
                            </select>
                        </div>
                        
                        <div class="col-12 mt-3">
                            <button type="submit" name="create" class="btn btn-primary w-100">
                                <i class="bi bi-plus-circle"></i> Buat Transaksi
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tabel Data Transaksi -->
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0"><i class="bi bi-list"></i> Daftar Transaksi</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Invoice</th>
                                <th>Member</th>
                                <th>Outlet</th>
                                <th>Tanggal</th>
                                <th>Deadline</th>
                                <th>Status</th>
                                <th>Pembayaran</th>
                                <th class="text-end">Total</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): 
                                // Tentukan class untuk status dan pembayaran
                                $status_class = 'status-' . $row['status'];
                                $payment_class = 'payment-' . ($row['payment_status'] == 'lunas' ? 'lunas' : 'belum');
                            ?>
                            <tr>
                                <td><strong><?= $row['invoice'] ?></strong></td>
                                <td><?= $row['member_name'] ?? 'Tidak diketahui' ?></td>
                                <td><?= $row['outlet_name'] ?? 'Tidak diketahui' ?></td>
                                <td><?= date('d/m/Y', strtotime($row['date'])) ?></td>
                                <td><?= date('d/m/Y', strtotime($row['deadline'])) ?></td>
                                <td><span class="badge rounded-pill <?= $status_class ?>"><?= ucfirst($row['status']) ?></span></td>
                                <td><span class="badge rounded-pill <?= $payment_class ?>"><?= ucfirst(str_replace('_', ' ', $row['payment_status'])) ?></span></td>
                                <td class="text-end">Rp <?= number_format($row['total'], 0, ',', '.') ?></td>
                                <td>
                                    <a href="transaksi.php?delete=<?= $row['id'] ?>" 
                                       class="btn btn-danger btn-sm" 
                                       onclick="return confirm('Yakin hapus transaksi <?= $row['invoice'] ?>?')">
                                        <i class="bi bi-trash"></i> Hapus
                                    </a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Set tanggal deadline default ke 3 hari dari sekarang
        document.addEventListener('DOMContentLoaded', function() {
            const today = new Date();
            const deadline = new Date();
            deadline.setDate(today.getDate() + 3);
            
            const deadlineInput = document.getElementById('deadline');
            deadlineInput.value = deadline.toISOString().split('T')[0];
            
            // Set minimum date to today
            const todayFormatted = today.toISOString().split('T')[0];
            deadlineInput.min = todayFormatted;
            
            // Inisialisasi total
            updateTotal();
        });

        // Tambah paket baru
        function addPackage() {
            const container = document.getElementById('packageContainer');
            const newPackage = document.createElement('div');
            newPackage.className = 'package-item row g-2';
            newPackage.innerHTML = `
                <div class="col-md-5">
                    <select class="form-select package-select" name="package_id[]" onchange="updateTotal()">
                        <option value="">Pilih Paket</option>
                        <?php foreach ($packages as $package): ?>
                            <option value="<?= $package['id'] ?>" data-price="<?= $package['price'] ?>">
                                <?= htmlspecialchars($package['name']) ?> - Rp <?= number_format($package['price'], 0, ',', '.') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="number" class="form-control package-qty" name="package_qty[]" value="1" min="1" onchange="updateTotal()" placeholder="Jumlah">
                </div>
                <div class="col-md-3">
                    <input type="text" class="form-control package-subtotal" readonly placeholder="Subtotal">
                </div>
                <div class="col-md-1">
                    <button type="button" class="btn btn-danger btn-sm remove-package" onclick="removePackage(this)">
                        <i class="bi bi-trash"></i>
                    </button>
                </div>
            `;
            container.appendChild(newPackage);
        }

        // Hapus paket
        function removePackage(button) {
            const packageItem = button.closest('.package-item');
            if (document.querySelectorAll('.package-item').length > 1) {
                packageItem.remove();
                updateTotal();
            } else {
                alert('Minimal harus ada satu paket');
            }
        }

        // Update total harga
        function updateTotal() {
            let total = 0;
            
            document.querySelectorAll('.package-item').forEach(item => {
                const select = item.querySelector('.package-select');
                const qtyInput = item.querySelector('.package-qty');
                const subtotalInput = item.querySelector('.package-subtotal');
                
                if (select.value && qtyInput.value) {
                    const price = parseFloat(select.selectedOptions[0].getAttribute('data-price'));
                    const qty = parseInt(qtyInput.value);
                    const subtotal = price * qty;
                    
                    subtotalInput.value = 'Rp ' + subtotal.toLocaleString('id-ID');
                    total += subtotal;
                } else {
                    subtotalInput.value = '';
                }
            });
            
            document.getElementById('total').value = 'Rp ' + total.toLocaleString('id-ID');
        }

        // Validasi form sebelum submit
        document.getElementById('transactionForm').addEventListener('submit', function(e) {
            let hasPackage = false;
            
            document.querySelectorAll('.package-select').forEach(select => {
                if (select.value) {
                    hasPackage = true;
                }
            });
            
            if (!hasPackage) {
                e.preventDefault();
                alert('Pilih minimal satu paket layanan');
                return false;
            }
            
            // Format total tanpa format currency untuk dikirim ke server
            const totalInput = document.getElementById('total');
            const totalValue = totalInput.value.replace('Rp ', '').replace(/\./g, '');
            totalInput.value = totalValue;
        });
    </script>
</body>
</html>