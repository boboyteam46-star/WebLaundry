<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Cek apakah user memiliki akses ke halaman berdasarkan role
$allowed_roles = [];

// Tentukan role yang diizinkan untuk setiap halaman
$current_page = basename($_SERVER['PHP_SELF']);
$admin_pages = ['dashboard.php', 'users.php', 'outlets.php', 'packages.php', 'members.php', 'transactions.php', 'reports.php'];
$cashier_pages = ['dashboard.php', 'members.php', 'transactions.php'];
$owner_pages = ['dashboard.php', 'reports.php'];

if ($_SESSION['role'] == 'admin' && in_array($current_page, $admin_pages)) {
    $allowed_roles = ['admin'];
} elseif ($_SESSION['role'] == 'kasir' && in_array($current_page, $cashier_pages)) {
    $allowed_roles = ['kasir'];
} elseif ($_SESSION['role'] == 'owner' && in_array($current_page, $owner_pages)) {
    $allowed_roles = ['owner'];
}

if (!in_array($_SESSION['role'], $allowed_roles)) {
    header("Location: ../unauthorized.php");
    exit;
}
?>