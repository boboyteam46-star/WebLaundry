<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<div class="container-fluid">
    <div class="row">
        <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-light sidebar collapse">
            <div class="position-sticky pt-3">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-speedometer2"></i>
                            Dashboard
                        </a>
                    </li>
                    <?php if ($_SESSION['role'] == 'admin'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="bi bi-people"></i>
                            Pengguna
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="outlets.php">
                            <i class="bi bi-shop"></i>
                            Outlet
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="packages.php">
                            <i class="bi bi-box-seam"></i>
                            Paket Layanan
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if ($_SESSION['role'] == 'admin' || $_SESSION['role'] == 'kasir'): ?>
                    <li class="nav-item">
                        <a class="nav-link" href="members.php">
                            <i class="bi bi-person-badge"></i>
                            Pelanggan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="transactions.php">
                            <i class="bi bi-cash-coin"></i>
                            Transaksi
                        </a>
                    </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <a class="nav-link" href="reports.php">
                            <i class="bi bi-bar-chart"></i>
                            Laporan
                        </a>
                    </li>
                </ul>
            </div>
        </nav>